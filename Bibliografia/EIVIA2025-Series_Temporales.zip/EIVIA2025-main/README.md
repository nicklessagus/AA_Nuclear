# EIVIA2025
Materials for the course "Deep Learning for Time Series and Applications to Healthcare" at the EIVIA2025 workshop.

